/**
 * FleetFlow Validation Engine
 * Enforces business rules for Safety, Capacity, and Compliance
 */

const Validation = {
    
    // 1. CAPACITY CHECK: Prevents vehicle overloading
    checkWeightLimit(cargoWeight, vehicleCapacity) {
        const weight = parseFloat(cargoWeight);
        const limit = parseFloat(vehicleCapacity);
        
        if (weight > limit) {
            return {
                isValid: false,
                message: `Overload: Cargo (${weight}kg) exceeds vehicle limit (${limit}kg).`,
                severity: 'high'
            };
        }
        return { isValid: true, message: "Weight within safe limits." };
    },

    // 2. COMPLIANCE CHECK: Prevents dispatching drivers with expired licenses
    checkLicenseStatus(expiryDate) {
        const today = new Date();
        const expiry = new Date(expiryDate);

        if (expiry < today) {
            return {
                isValid: false,
                message: "Compliance Alert: Driver's license is expired. Dispatch blocked.",
                severity: 'critical'
            };
        }
        return { isValid: true };
    },

    // 3. OPERATIONAL CHECK: Ensures vehicle is ready for duty
    checkVehicleReadiness(status) {
        if (status === 'In Shop') {
            return {
                isValid: false,
                message: "Maintenance Alert: Vehicle is currently under repair.",
                severity: 'medium'
            };
        }
        if (status === 'On Trip') {
            return {
                isValid: false,
                message: "Assignment Error: Vehicle is already active on another route.",
                severity: 'medium'
            };
        }
        return { isValid: true };
    },

    // 4. UI FEEDBACK: Helper to display errors on forms
    showError(elementId, result) {
        const el = document.getElementById(elementId);
        if (!el) return;

        if (!result.isValid) {
            el.innerHTML = `
                <div class="p-3 bg-red-500/10 border border-red-500/20 rounded-lg text-red-400 text-xs flex items-start">
                    <span class="mr-2">⚠️</span>
                    <span>${result.message}</span>
                </div>
            `;
            return false;
        } else {
            el.innerHTML = "";
            return true;
        }
    }
};