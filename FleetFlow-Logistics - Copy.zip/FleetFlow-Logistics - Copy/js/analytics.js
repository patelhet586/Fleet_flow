/**
 * FleetFlow Analytics Engine
 * Purpose: Cross-references Trips, Vehicles, and Maintenance JSON
 * to provide Financial ROI and Fuel Efficiency insights.
 */

const Analytics = {
    async init() {
        try {
            // 1. Fetch the raw data
            const [vRes, tRes, mRes] = await Promise.all([
                fetch('/api/vehicles'),
                fetch('/api/trips'),
                fetch('/api/maintenance')
            ]);

            const vehicles = await vRes.json();
            const trips = await tRes.json();
            const maintenance = await mRes.json();

            this.calculateFinancials(trips, maintenance);
            this.renderEfficiencyLeaderboard(vehicles, trips);
            
        } catch (err) {
            console.error("Analytics Engine Error:", err);
        }
    },

    // --- 2. FINANCIAL CALCULATIONS ---
    calculateFinancials(trips, maintenance) {
        // Total Maintenance Spend
        const totalMaint = maintenance.reduce((sum, log) => sum + log.cost, 0);

        // Fuel Spend (Assume average Rs. 100 per Liter)
        const totalFuelLitres = trips.reduce((sum, trip) => sum + trip.fuel_consumed_l, 0);
        const fuelCost = totalFuelLitres * 100;

        const totalExpenses = totalMaint + fuelCost;
        const totalKm = trips.reduce((sum, trip) => sum + trip.distance_km, 0);
        const costPerKm = (totalExpenses / totalKm).toFixed(2);

        // Update UI IDs in analytics.html
        this.updateUI('total-expenses', `Rs. ${totalExpenses.toLocaleString()}`);
        this.updateUI('avg-cost-km', `Rs. ${costPerKm}`);
        this.updateUI('fleet-fuel-avg', `${(totalKm / totalFuelLitres).toFixed(1)} km/L`);
    },

    // --- 3. ASSET ROI LEADERBOARD ---
    renderEfficiencyLeaderboard(vehicles, trips) {
        const tbody = document.getElementById('analytics-table-body');
        if (!tbody) return;

        // Group trips by vehicle to find the "Top Performers"
        const vehicleStats = vehicles.map(v => {
            const vTrips = trips.filter(t => t.vehicle_id === v.id);
            const vKm = vTrips.reduce((sum, t) => sum + t.distance_km, 0);
            const vFuel = vTrips.reduce((sum, t) => sum + t.fuel_consumed_l, 0);
            
            return {
                id: v.id,
                model: v.name_model,
                km: vKm,
                fuel: vFuel,
                efficiency: vFuel > 0 ? (vKm / vFuel).toFixed(1) : 0,
                status: v.status
            };
        });

        // Sort by most efficient first
        vehicleStats.sort((a, b) => b.efficiency - a.efficiency);

        tbody.innerHTML = vehicleStats.slice(0, 15).map(stat => `
            <tr class="hover:bg-slate-700/30 transition-colors">
                <td class="px-6 py-4 font-bold text-white">${stat.id}</td>
                <td class="px-6 py-4 text-slate-400">${stat.model}</td>
                <td class="px-6 py-4">${stat.km.toLocaleString()} km</td>
                <td class="px-6 py-4">${stat.fuel.toFixed(1)} L</td>
                <td class="px-6 py-4 text-emerald-400 font-bold">${stat.efficiency} km/L</td>
                <td class="px-6 py-4">
                    <span class="status-pill ${this.getStatusClass(stat.status)}">${stat.status}</span>
                </td>
            </tr>
        `).join('');
    },

    getStatusClass(status) {
        if (status === 'On Trip') return 'status-ontrip';
        if (status === 'In Shop') return 'status-inshop';
        return 'status-available';
    },

    updateUI(id, val) {
        const el = document.getElementById(id);
        if (el) el.innerText = val;
    }
};

// Start calculation when component is ready
Analytics.init();