/**
 * FleetFlow Finance & Audit Engine
 * Cross-references Trip data with Maintenance costs for P&L Reporting
 */

const Finance = {
    // Current Fuel Price Constant for Hackathon Demo
    FUEL_PRICE_PER_LITER: 1.45, 

    async init() {
        try {
            const [tRes, mRes] = await Promise.all([
                fetch('/api/trips'),
                fetch('/api/maintenance')
            ]);

            const trips = await tRes.json();
            const maintenance = await mRes.json();

            this.processFinancialReports(trips, maintenance);
        } catch (err) {
            console.error("Finance Data Error:", err);
        }
    },

    processFinancialReports(trips, maintenance) {
        // 1. Calculate Total Maintenance Outflow
        const totalMaint = maintenance.reduce((sum, item) => sum + item.cost, 0);

        // 2. Calculate Total Fuel Expenditure
        const totalFuelLitres = trips.reduce((sum, item) => sum + item.fuel_consumed_l, 0);
        const totalFuelCost = totalFuelLitres * this.FUEL_PRICE_PER_LITER;

        // 3. Operational Calculations
        const totalOperationalCost = totalMaint + totalFuelCost;
        const totalKm = trips.reduce((sum, item) => sum + item.distance_km, 0);
        const costPerKm = totalKm > 0 ? (totalOperationalCost / totalKm).toFixed(2) : 0;

        // 4. Update the Analytics/Finance UI
        this.updateFinanceUI({
            maint: totalMaint,
            fuel: totalFuelCost,
            total: totalOperationalCost,
            cpkm: costPerKm
        });
    },

    updateFinanceUI(stats) {
        // Mapping results to the HTML IDs in analytics.html
        const elements = {
            'total-expenses': `Rs. ${stats.total.toLocaleString()}`,
            'avg-cost-km': `Rs. ${stats.cpkm}`,
            'maint-total': `Rs. ${stats.maint.toLocaleString()}`
        };

        for (const [id, value] of Object.entries(elements)) {
            const el = document.getElementById(id);
            if (el) el.innerText = value;
        }
    }
};

// Remove global initialization - now called only from app.js when analytics.html is loaded