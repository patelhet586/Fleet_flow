/**
 * FleetFlow Registry Engine
 * Handles full fleet rendering, real-time search, and status filtering
 */

const Registry = {
    allVehicles: [],

    async init() {
        try {
            const response = await fetch('/api/vehicles');
            this.allVehicles = await response.json();

            this.renderTable(this.allVehicles);
        } catch (err) {
            console.error("Registry Load Error:", err);
            const tbody = document.getElementById('fleet-table-body');
            if (tbody) tbody.innerHTML = `<tr><td colspan="7" class="text-center p-10 text-red-400">Failed to load vehicle database.</td></tr>`;
        }
    },

    // --- 1. RENDER ENGINE ---
    renderTable(data) {
        const tbody = document.getElementById('fleet-table-body');
        if (!tbody) return;

        if (!Array.isArray(data) || data.length === 0) {
            tbody.innerHTML = `<tr><td colspan="7" class="text-center p-10 text-slate-500">No vehicles match your search.</td></tr>`;
            return;
        }

        tbody.innerHTML = data.map(v => `
            <tr class="hover:bg-slate-700/30 transition-colors border-b border-slate-700/50">
                <td class="px-6 py-4 font-bold text-white">${v.id}</td>
                <td class="px-6 py-4 font-medium text-slate-200">${v.name_model}</td>
                <td class="px-6 py-4 font-mono text-blue-400 text-xs">${v.license_plate}</td>
                <td class="px-6 py-4 text-slate-400">${v.type}</td>
                <td class="px-6 py-4">${Number(v.max_load_kg || 0).toLocaleString()} kg</td>
                <td class="px-6 py-4 text-slate-400">${Number(v.current_odometer || 0).toLocaleString()} km</td>
                <td class="px-6 py-4">
                    <span class="status-pill ${this.getStatusClass(v.status)}">
                        ${v.status}
                    </span>
                </td>
            </tr>
        `).join('');
    },

    // --- 2. SEARCH & FILTER LOGIC ---
    handleSearch(query) {
        const q = query.toLowerCase();
        const filtered = this.allVehicles.filter(v => 
            v.id.toLowerCase().includes(q) || 
            v.license_plate.toLowerCase().includes(q) || 
            v.name_model.toLowerCase().includes(q)
        );
        this.renderTable(filtered);
    },

    filterByStatus(status) {
        if (status === 'All') {
            this.renderTable(this.allVehicles);
        } else {
            const filtered = this.allVehicles.filter(v => v.status === status);
            this.renderTable(filtered);
        }
    },

    // --- 3. UTILITIES ---
    getStatusClass(status) {
        if (status === 'On Trip') return 'status-ontrip';
        if (status === 'In Shop') return 'status-inshop';
        return 'status-available';
    }
};

// Initialize when the registry component is loaded into the DOM
Registry.init();

// Refresh registry when backend-mutating actions occur elsewhere
window.addEventListener('dataUpdated', () => {
    Registry.init();
});