/**
 * FleetFlow Master Controller
 * Handles Navigation, Role-Based Access, and Script Execution
 */

const App = {
    init() {
        this.checkAuth();
    },

    // Theme handling
    initTheme() {
        const t = localStorage.getItem('theme') || 'dark';
        if (t === 'light') document.body.classList.add('light');
        this.updateThemeButton();
    },

    toggleTheme() {
        const isLight = document.body.classList.toggle('light');
        localStorage.setItem('theme', isLight ? 'light' : 'dark');
        this.updateThemeButton();
    },

    updateThemeButton() {
        const btn = document.getElementById('themeToggle');
        if (!btn) return;
        btn.innerText = document.body.classList.contains('light') ? '☀️' : '🌙';
    },

    // Authorization: simple role->capability map
    permissions: {
        addVehicle: ['Manager'],
        dispatchTrip: ['Dispatcher','Manager'],
        logMaintenance: ['Safety','Manager'],
        viewAnalytics: ['Finance','Manager']
    },

    getUserRole() {
        return localStorage.getItem('userRole') || null;
    },

    hasPermission(action) {
        const role = this.getUserRole();
        if (!role) return false;
        const allowed = this.permissions[action];
        if (!allowed) return false; // unknown action => deny
        return allowed.includes(role);
    },

    applyPermissions() {
        const nodes = document.querySelectorAll('[data-perm]');
        nodes.forEach(n => {
            const action = n.getAttribute('data-perm');
            if (!this.hasPermission(action)) {
                n.classList.add('locked');
                n.classList.remove('unlocked');
                n.style.pointerEvents = 'none';
                n.style.opacity = 0.5;
                n.title = 'Locked for your role';
            } else {
                n.classList.remove('locked');
                n.classList.add('unlocked');
                n.style.pointerEvents = '';
                n.style.opacity = 1;
                n.title = '';
            }
        });
    },

    checkAuth() {
        const isLoggedIn = localStorage.getItem('isLoggedIn');
        const userRole = localStorage.getItem('userRole');
        
        const authContainer = document.getElementById('auth-container');
        const mainContent = document.getElementById('main-content');

        if (isLoggedIn === 'true' && userRole) {
            authContainer.classList.add('hidden');
            mainContent.classList.remove('hidden');
            mainContent.style.display = 'flex'; 
            this.renderLayout(userRole);
        } else {
            authContainer.classList.remove('hidden');
            mainContent.classList.add('hidden');
        }
    },

    async renderLayout(role) {
        const mainContent = document.getElementById('main-content');
        try {
            const res = await fetch('components/sidebar.html');
            let sidebarHtml = await res.text();

            // Sidebar tab filtering by role
            const roleTabs = {
                'Manager': ['dashboard', 'registry'],
                'Dispatcher': ['dispatcher'],
                'Safety': ['drivers', 'safety'],
                'Finance': ['analytics']
            };
            const allowed = roleTabs[role] || [];
            // Remove all nav buttons not allowed for this role
            sidebarHtml = sidebarHtml.replace(/<button ([^>]*?)onclick="App\.loadComponent\('([^']+)'\)"[^>]*>[\s\S]*?<\/button>/g, (match, attrs, comp) => {
                if (allowed.includes(comp)) return match;
                return '';
            });

            mainContent.innerHTML = `
                ${sidebarHtml}
                <div id="page-container" class="flex-1 overflow-y-auto p-8 bg-[#0f172a]">
                    <div class="animate-pulse text-blue-500">Establishing Secure Connection...</div>
                </div>
            `;

            // Display actual role in sidebar
            const roleDisplay = document.getElementById('user-display-role');
            if(roleDisplay) roleDisplay.innerText = role;

            // Route to initial page based on role: Managers go to Registry by default
            let startPage = 'dashboard';
            if (role === 'Manager') startPage = 'registry';
            else if (allowed.length > 0) startPage = allowed[0];
            this.loadComponent(startPage);

        } catch (err) {
            console.error("Layout Error:", err);
        }
    },

    async loadComponent(page) {
        const container = document.getElementById('page-container');
        if (!container) return;

        // FIXED: Maps your Sidebar calls to your actual File Names
        const pageMap = {
            'dashboard': 'dashboard.html',
            'manager': 'dashboard.html',
            'registry': 'registry.html',
            'dispatcher': 'dispatcher.html',
            'drivers': 'drivers.html',
            'safety': 'safety.html',
            'compliance': 'safety.html',
            'analytics': 'analytics.html',
            'finance': 'analytics.html'
        };

        const fileName = pageMap[page.toLowerCase()] || 'dashboard.html';

        try {
            const response = await fetch(`components/${fileName}`);
            const html = await response.text();
            container.innerHTML = html;

            // Execute any inline scripts from the loaded component so functions are defined
            const scripts = Array.from(container.querySelectorAll('script'));
            for (const s of scripts) {
                const newScript = document.createElement('script');
                if (s.src) {
                    newScript.src = s.src;
                } else {
                    newScript.textContent = s.textContent;
                }
                document.body.appendChild(newScript);
                document.body.removeChild(newScript);
            }

            // track currently loaded file for refreshes
            this.currentFile = fileName;

            // Initialize data and behaviors for the loaded page
            this.initPageData(fileName);
            // Re-apply permissions after page init so controls reflect role
            this.applyPermissions();

        } catch (err) {
            container.innerHTML = `<div class="p-10 text-red-400">Error: components/${fileName} not found.</div>`;
        }
    },

    initPageData(fileName) {
        console.log("Initializing data for:", fileName);
        
        switch(fileName) {
            case 'dashboard.html':
                this.syncDashboardData();
                if (typeof loadDashboardData === 'function') loadDashboardData();
                break;
            case 'registry.html':
                if (typeof Registry !== 'undefined') Registry.init();
                break;
            case 'dispatcher.html':
                if (typeof initDispatcher === 'function') initDispatcher();
                break;
            case 'analytics.html':
                if (typeof Analytics !== 'undefined') Analytics.init();
                if (typeof Finance !== 'undefined') Finance.init();
                break;
            case 'drivers.html':
                if (typeof loadDriversData === 'function') loadDriversData();
                break;
            case 'safety.html':
                // Call maintenance data function
                if (typeof loadMaintenanceData === 'function') loadMaintenanceData();
                break;
        }
    },

    // Called when backend-mutating actions happen elsewhere (maintenance, dispatch, registry adds)
    onDataUpdated() {
        if (this.currentFile) this.initPageData(this.currentFile);
    },

    async syncDashboardData() {
        try {
            const [vRes, tRes] = await Promise.all([
                fetch('/api/vehicles'),
                fetch('/api/trips')
            ]);
            const vehicles = await vRes.json();
            
            if(document.getElementById('stat-active')) {
                document.getElementById('stat-active').innerText = vehicles.filter(v => v.status === 'On Trip').length;
            }
            if(document.getElementById('stat-maintenance')) {
                document.getElementById('stat-maintenance').innerText = vehicles.filter(v => v.status === 'In Shop').length;
            }
        } catch (e) { console.warn("Data sync failed. Check backend server."); }
    },

    logout() {
        localStorage.clear();
        location.reload();
    }
};

document.addEventListener('DOMContentLoaded', () => App.init());

// Global listener for backend changes
window.addEventListener('dataUpdated', () => {
    if (typeof App.onDataUpdated === 'function') App.onDataUpdated();
});

// Expose toggleTheme globally so sidebar can call it
window.toggleTheme = () => App.toggleTheme();

// Initialize theme immediately
document.addEventListener('DOMContentLoaded', () => {
    if (typeof App.initTheme === 'function') App.initTheme();
});