/**
 * FleetFlow Authentication Logic
 * Handles Login, Registration, and Role Persistence
 */

document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginAction');
    const registerForm = document.getElementById('registerAction');

    // --- 1. LOGIN HANDLER ---
    if (loginForm) {
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();

            const selectedRole = document.querySelector('input[name="role"]:checked').value;
            const email = loginForm.querySelector('input[type="email"]').value;
            // Direct access: allow any password
            // Retrieve users from localStorage
            let users = JSON.parse(localStorage.getItem('fleetUsers') || '[]');
            let user = users.find(u => u.email === email);
            if (!user) {
                // If not registered, create a demo user
                user = { name: email.split('@')[0], email, role: selectedRole };
            }
            localStorage.setItem('isLoggedIn', 'true');
            localStorage.setItem('userRole', user.role);
            localStorage.setItem('userEmail', user.email);
            localStorage.setItem('userName', user.name);
            window.location.reload();
        });
    }

    // --- 2. REGISTRATION HANDLER ---
    if (registerForm) {
        registerForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const fullName = registerForm.querySelector('input[type="text"]').value;
            const email = registerForm.querySelector('input[type="email"]').value;
            const password = document.getElementById('regPassword') ? document.getElementById('regPassword').value : '';
            const confirm = document.getElementById('regConfirmPassword') ? document.getElementById('regConfirmPassword').value : '';
            const selectedRole = document.querySelector('input[name="role"]:checked').value;

            if (!password || password.length < 6) {
                alert('Password must be at least 6 characters.');
                return;
            }
            if (password !== confirm) {
                alert('Passwords do not match.');
                return;
            }

            // Save user to localStorage
            let users = JSON.parse(localStorage.getItem('fleetUsers') || '[]');
            if (users.some(u => u.email === email)) {
                alert('Account with this email already exists.');
                return;
            }
            users.push({
                name: fullName,
                email,
                password,
                role: selectedRole
            });
            localStorage.setItem('fleetUsers', JSON.stringify(users));

            // Save session
            localStorage.setItem('isLoggedIn', 'true');
            localStorage.setItem('userRole', selectedRole);
            localStorage.setItem('userName', fullName);
            localStorage.setItem('userEmail', email);

            alert("Account created successfully!");
            window.location.reload();
        });
    }
});
// (legacy stray block removed)