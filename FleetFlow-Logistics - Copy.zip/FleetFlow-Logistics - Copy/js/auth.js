/**
 * FleetFlow Authentication Logic
 * Handles Login, Registration, and Role Persistence
 */

document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginAction');
    const registerForm = document.getElementById('registerAction');

    // --- 1. LOGIN HANDLER ---
    if (loginForm) {
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();

            // Capture the selected role from the radio buttons
            const selectedRole = document.querySelector('input[name="role"]:checked').value;
            
            // Mock validation (Accepts any input for the hackathon)
            const email = loginForm.querySelector('input[type="email"]').value;
            const password = loginForm.querySelector('input[type="password"]').value;

            if (email && password) {
                // Save session to LocalStorage
                localStorage.setItem('isLoggedIn', 'true');
                localStorage.setItem('userRole', selectedRole);
                localStorage.setItem('userEmail', email);

                console.log(`Login Successful as ${selectedRole}`);
                
                // Trigger App to reload and show Dashboard
                window.location.reload(); 
            } else {
                alert("Please enter valid credentials.");
            }
        });
    }

    // --- 2. REGISTRATION HANDLER ---
    if (registerForm) {
        registerForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const fullName = registerForm.querySelector('input[type="text"]').value;
            const email = registerForm.querySelector('input[type="email"]').value;
            const password = document.getElementById('regPassword') ? document.getElementById('regPassword').value : '';
            const confirm = document.getElementById('regConfirmPassword') ? document.getElementById('regConfirmPassword').value : '';
            const selectedRole = document.querySelector('input[name="role"]:checked').value;

            if (!password || password.length < 6) {
                alert('Password must be at least 6 characters.');
                return;
            }
            if (password !== confirm) {
                alert('Passwords do not match.');
                return;
            }

            // Save basic info
            localStorage.setItem('isLoggedIn', 'true');
            localStorage.setItem('userRole', selectedRole);
            localStorage.setItem('userName', fullName);
            localStorage.setItem('userEmail', email);

            alert("Account created successfully!");
            window.location.reload();
        });
    }
});
// (legacy stray block removed)