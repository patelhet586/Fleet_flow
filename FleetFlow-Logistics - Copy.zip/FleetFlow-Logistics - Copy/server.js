const express = require('express');
const path = require('path');
const fs = require('fs');
let Database;
try {
    Database = require('better-sqlite3');
} catch (e) {
    console.warn('better-sqlite3 not available — falling back to JSON file storage. To use SQLite, install better-sqlite3 and C++ build tools.');
    Database = null;
}
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// Serve the frontend static files (project root)
app.use(express.static(path.join(__dirname)));

// Initialization: either SQLite-backed or JSON file-backed
const DB_PATH = path.join(__dirname, 'fleetflow.db');

// File storage helpers (fallback)
const wrapperMap = {};
function readJsonFile(name) {
    try {
        const p = path.join(__dirname, 'data', name);
        if (!fs.existsSync(p)) return [];
        const parsed = JSON.parse(fs.readFileSync(p));
        // Support legacy format: { value: [ ... ], Count: N }
        if (parsed && typeof parsed === 'object' && Array.isArray(parsed.value)) {
            wrapperMap[name] = true;
            return parsed.value;
        }
        wrapperMap[name] = false;
        return parsed;
    } catch (e) { console.warn('readJsonFile error', e); }
    return [];
}
function writeJsonFile(name, data) {
    try {
        const p = path.join(__dirname, 'data', name);
        if (wrapperMap[name]) {
            const wrapped = { value: data, Count: Array.isArray(data) ? data.length : 0 };
            fs.writeFileSync(p, JSON.stringify(wrapped, null, 2));
        } else {
            fs.writeFileSync(p, JSON.stringify(data, null, 2));
        }
    } catch (e) { console.warn('writeJsonFile error', e); }
}

let useSqlite = !!Database;
let db = null;
if (useSqlite) {
    try {
        db = new Database(DB_PATH);
        // ensure tables exist (same schema as before)
        db.prepare(`CREATE TABLE IF NOT EXISTS vehicles (
            id TEXT PRIMARY KEY,
            name_model TEXT,
            license_plate TEXT,
            type TEXT,
            max_load_kg INTEGER,
            current_odometer INTEGER,
            status TEXT
        )`).run();
        db.prepare(`CREATE TABLE IF NOT EXISTS drivers (
            id TEXT PRIMARY KEY,
            full_name TEXT,
            license_number TEXT,
            license_expiry TEXT,
            category TEXT,
            safety_score REAL,
            status TEXT
        )`).run();
        db.prepare(`CREATE TABLE IF NOT EXISTS trips (
            trip_id TEXT PRIMARY KEY,
            vehicle_id TEXT,
            driver_id TEXT,
            origin TEXT,
            destination TEXT,
            cargo_weight_kg INTEGER,
            distance_km INTEGER,
            fuel_consumed_l REAL,
            status TEXT,
            date TEXT
        )`).run();
        db.prepare(`CREATE TABLE IF NOT EXISTS maintenance (
            log_id TEXT PRIMARY KEY,
            vehicle_id TEXT,
            service_type TEXT,
            cost REAL,
            date TEXT,
            technician TEXT,
            status TEXT
        )`).run();

        // Seed if empty (same logic)
        const vCount = db.prepare('SELECT COUNT(1) as c FROM vehicles').get().c;
        if (vCount === 0) {
            const vehicles = readJsonFile('vehicles.json');
            const insert = db.prepare('INSERT INTO vehicles (id,name_model,license_plate,type,max_load_kg,current_odometer,status) VALUES (?,?,?,?,?,?,?)');
            const insertMany = db.transaction((rows) => { for (const r of rows) insert.run(r.id, r.name_model, r.license_plate, r.type, r.max_load_kg, r.current_odometer, r.status); });
            insertMany(vehicles);
            console.log('Seeded vehicles (sqlite)');
        }
    } catch (e) {
        console.warn('SQLite init failed, falling back to JSON files', e);
        useSqlite = false;
    }
}

// In-memory / file-backed datasets (used when SQLite not available)
let vehicles = readJsonFile('vehicles.json');
let drivers = readJsonFile('drivers.json');
let trips = readJsonFile('trips.json');
let maintenance = readJsonFile('maintenance.json');

function persistAll() {
    writeJsonFile('vehicles.json', vehicles);
    writeJsonFile('drivers.json', drivers);
    writeJsonFile('trips.json', trips);
    writeJsonFile('maintenance.json', maintenance);
}

// API Endpoints
app.get('/api/vehicles', (req, res) => {
    if (useSqlite) {
        const rows = db.prepare('SELECT * FROM vehicles').all();
        res.json(rows);
    } else {
        res.json(vehicles);
    }
});

app.post('/api/vehicles', (req, res) => {
    const v = req.body;
    try {
        if (useSqlite) {
            db.prepare('INSERT INTO vehicles (id,name_model,license_plate,type,max_load_kg,current_odometer,status) VALUES (?,?,?,?,?,?,?)')
                .run(v.id, v.name_model, v.license_plate, v.type, v.max_load_kg, v.current_odometer, v.status || 'Available');
        } else {
            vehicles.push({ id: v.id, name_model: v.name_model, license_plate: v.license_plate, type: v.type, max_load_kg: v.max_load_kg, current_odometer: v.current_odometer || 0, status: v.status || 'Available' });
            persistAll();
        }
        res.status(201).json({ok: true});
    } catch (e) { res.status(500).json({error: e.message}); }
});

app.get('/api/drivers', (req, res) => {
    if (useSqlite) {
        const rows = db.prepare('SELECT * FROM drivers').all();
        res.json(rows);
    } else {
        res.json(drivers);
    }
});

app.get('/api/trips', (req, res) => {
    if (useSqlite) {
        const rows = db.prepare('SELECT * FROM trips').all();
        res.json(rows);
    } else {
        res.json(trips);
    }
});

app.post('/api/trips', (req, res) => {
    const t = req.body;
    const tripId = t.trip_id || `T-${Date.now()}`;
    try {
        if (useSqlite) {
            const insert = db.prepare('INSERT INTO trips (trip_id,vehicle_id,driver_id,origin,destination,cargo_weight_kg,distance_km,fuel_consumed_l,status,date) VALUES (?,?,?,?,?,?,?,?,?,?)');
            insert.run(tripId, t.vehicle_id, t.driver_id, t.origin, t.destination, t.cargo_weight_kg || 0, t.distance_km || 0, t.fuel_consumed_l || 0, t.status || 'Dispatched', t.date || new Date().toISOString().split('T')[0]);
            db.prepare('UPDATE vehicles SET status = ? WHERE id = ?').run('On Trip', t.vehicle_id);
            db.prepare('UPDATE drivers SET status = ? WHERE id = ?').run('On Trip', t.driver_id);
        } else {
            trips.push({ trip_id: tripId, vehicle_id: t.vehicle_id, driver_id: t.driver_id, origin: t.origin, destination: t.destination, cargo_weight_kg: t.cargo_weight_kg || 0, distance_km: t.distance_km || 0, fuel_consumed_l: t.fuel_consumed_l || 0, status: t.status || 'Dispatched', date: t.date || new Date().toISOString().split('T')[0] });
            // Update vehicle and driver status in arrays
            const vi = vehicles.find(v => v.id === t.vehicle_id);
            if (vi) vi.status = 'On Trip';
            const di = drivers.find(d => d.id === t.driver_id);
            if (di) di.status = 'On Trip';
            persistAll();
        }
        res.status(201).json({trip_id: tripId});
    } catch (e) { res.status(500).json({error: e.message}); }
});

app.get('/api/maintenance', (req, res) => {
    if (useSqlite) {
        const rows = db.prepare('SELECT * FROM maintenance').all();
        res.json(rows);
    } else {
        res.json(maintenance);
    }
});

app.post('/api/maintenance', (req, res) => {
    const m = req.body;
    const logId = m.log_id || `M-${Date.now()}`;
    try {
        if (useSqlite) {
            db.prepare('INSERT INTO maintenance (log_id,vehicle_id,service_type,cost,date,technician,status) VALUES (?,?,?,?,?,?,?)')
                .run(logId, m.vehicle_id, m.service_type, m.cost || 0, m.date || new Date().toISOString().split('T')[0], m.technician || '', m.status || 'In Progress');
            db.prepare('UPDATE vehicles SET status = ? WHERE id = ?').run('In Shop', m.vehicle_id);
        } else {
            maintenance.push({ log_id: logId, vehicle_id: m.vehicle_id, service_type: m.service_type, cost: m.cost || 0, date: m.date || new Date().toISOString().split('T')[0], technician: m.technician || '', status: m.status || 'In Progress' });
            const v = vehicles.find(x => x.id === m.vehicle_id);
            if (v) v.status = 'In Shop';
            persistAll();
        }

        res.status(201).json({log_id: logId});
    } catch (e) { res.status(500).json({error: e.message}); }
});

// Fallback to index
app.get('*', (req, res) => {
    const indexPath = path.join(__dirname, 'index.html');
    if (fs.existsSync(indexPath)) res.sendFile(indexPath);
    else res.status(404).send('Not found');
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
